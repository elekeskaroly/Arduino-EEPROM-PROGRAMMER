import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.core.*; 
import processing.event.*; 
import controlP5.*; 
import geomerative.*; 
import processing.serial.*; 
import java.util.Map; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class EEPROM_programer extends PApplet {









long baudRate =500000;

PImage img;
PImage ico;
int error_count=0;     // variable for counting errors
int byte_count=0;      // variable for counting bytes
int epromsize=0x1F40;  //Set default EEPROM size;
int step=0;
int epromadress=0;

boolean process=false; 
boolean wait=true;
boolean file_event=false;
boolean openfile;
boolean savefile;

boolean init_state=false;
boolean connected_status=false;
boolean readeprom=false;
boolean writeeprom=false;
boolean eraseeeprom=false;
String  status_msg;
String str1;
String str2="";
String val;
String data1="";
String sfilename;
String data11;
String serialstring;

ControlP5 cp5;
Serial myPort;  //the Serial port object
PApplet applet = this;
PFont myFont;
int bcolor = color(150,150,160);
ArrayList<String> comPorts = new ArrayList<String>();
// -----  SETUP -----  //

public void setup() {
  
  surface.setTitle("Eeprom - programmer  v0.1");
  img = loadImage("eprom.png");
  listPorts();  
  createcp5GUI();
  noStroke();
  
  textAlign(LEFT);
  myFont = createFont("Segoe UI", 12);
  status_msg="--";
  init_state=false;
 }



public void draw() {
  background(bcolor);
  fill(0xffaa0000);
  rect(-1,598,510,26);
  noFill();
  stroke(10,10,60);  
  rect(19,149,461,401);
  fill(0xfffcfcfc);
  image(img, 20, 50);
  textFont(createFont("Courier New", 13));
  text("00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F",83,145);
  textFont(myFont);
  text("| size: "+str(epromsize)+" bytes", 380, 613);
  if (connected_status==true) text("| Connected |",20,613); else  text("| Not connected |",20,613);
  float a =myTextarea.getScrollPosition();
  myTextarea2.scroll(1-a);
  cp5.draw();
  text(status_msg,120,613);

// -----  SAVE FILE ---- 
if (file_event==true & savefile==true) {
    byte[] nums=new byte[epromsize];
    if (data1!="") {
                    String[] q = splitTokens(data1);
                    for (int i=0; i<epromsize;i++){
                         int j =unhex(q[i]);
                         nums[i]=PApplet.parseByte(j); }
                     if (sfilename!=null) saveBytes(sfilename, nums);
                    }
    savefile=false;
    file_event=false;
   }

// -----  OPEN FILE ----
if (file_event==true & openfile==true){
  data1="";
  str2=hex(0).substring(4,8)+": \n";
  int j=0;
  // Open a file and read its binary data 
    byte b[] = loadBytes(sfilename); 
    for (int i = 0; i < b.length; i++) {
        data1=data1+hex(b[i])+" ";
        status_msg=str(i+1)+" bytes loaded.";
        if (j>15) {j=0; str2=str2+hex(i).substring(4,8)+": \n";}
        j++;}
  myTextarea2.setText(str2);
  myTextarea.setText(data1);
  file_event=false;
  openfile=false;
 }
 
 
// -----  ERASE EEPROM ----

if (eraseeeprom==true) {
  if (init_state==true){
      String str="a"+hex(epromadress).substring(4,8)+":[FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF ]";
      boolean next=false;
      myPort.write(str);
      delay(1);
      while (next==false) {
        serialstring = myPort.readStringUntil('\n');
        if (serialstring==null) {myPort.write(str);delay(5);}
        if (serialstring!=null) {
                                  if (serialstring.contains("ok")) {
                                              next=true;
                                              epromadress+=32;
                                              slider1.setValue(epromadress);
                                              byte_count++;}
                                 }    
                             }
                             
       if (epromadress>=epromsize) {eraseeeprom=false;
                                    clearbutton.setCaptionLabel("Erase");
                                    error_count=0;
                                    status_msg=status_msg+" OK";
                                    epromadress=0;
                                    byte_count=0;
                                    step=0;
                                    slider1.setVisible(false);}
   }} 
  


// -----  WRITE EEPROM ----

if (writeeprom==true) {
 if (init_state==true){
      data11=data1.substring(step,step+96);
      String str="a"+hex(epromadress).substring(4,8)+":["+data11+"]";
      boolean next=false;
      myPort.write(str);
      delay(1);
   
      while (next==false) {
        serialstring = myPort.readStringUntil('\n');
        if (serialstring==null) {myPort.write(str);delay(5);}        
        if (serialstring!=null) {if (serialstring.contains("ok")) {
                                    next=true;
                                    epromadress+=32;
                                    slider1.setValue(epromadress);
                                    byte_count++;
                                    step+=96;}
                                }    
                          }

    if (epromadress>=epromsize) {writeeprom=false;
                                 writebutton.setCaptionLabel("Write");
                                 error_count=0;
                                 status_msg=str(byte_count)+" bytes written: 0000 to "+hex(byte_count).substring(4,8);
                                 epromadress=0;
                                 byte_count=0;
                                 step=0;slider1.setVisible(false);}
     }  
}
  
  


   
if (readeprom==true) {
 
if (init_state==true) {
  String str="m"+hex(epromadress).substring(4,8);
  myPort.write(str);delay(2);
  process=false;
  boolean next=false;
      while (next==false) {
      serialstring = myPort.readStringUntil('\n');
      if (serialstring==null)  { myPort.write(str);delay(2);}
      if (serialstring!=null)  {//println(serialstring);//re=hex(br).substring(4,8)+":"+str(er)+" errors !";
                                //if (serialstring.contains("error")) { println("E01");serialstring=null;next=true;process=false;error_count=er+1;re=hex(br).substring(4,8)+"   Corrected: "+str(er)+" errors !";}else 
                                {next=true;
                                 epromadress+=64;
                                 process=true;}
                                }
  if (process==true) {
      int l =serialstring.indexOf('[');
      int le =serialstring.indexOf(']');
      String s=serialstring.substring(l+1,le-1);
      String[] q = splitTokens(s);
      str2=str2+hex(epromadress-64).substring(4,8)+": \n"+hex(epromadress-48).substring(4,8)+": \n"+hex(epromadress-32).substring(4,8)+": \n"+hex(epromadress-16).substring(4,8)+": \n";
      for (int i=0; i<q.length;i++){
                                    data1=data1+q[i]+" ";
                                    byte_count++;
                                   }
      myTextarea2.setText(str2);
      myTextarea.setText(data1);
      slider1.setValue(epromadress);}
    }
    
    if (epromadress>=epromsize) {readeprom=false;
                                 readbutton.setCaptionLabel("Read EEPROM");
                                 error_count=0;
                                 status_msg=str(byte_count)+" bytes read sucessfully. From: 0000 to "+hex(byte_count-1).substring(4,8);
                                 epromadress=0;byte_count=0;
                                 slider1.setVisible(false);}
  }
 else {status_msg="No connection !";readeprom=false;}
}
}
 
  
  
ArrayList<Byte> bytes = new ArrayList<Byte>();
String val2;
 public void listPorts() {
        comPorts.add("Disconnect");
        for (int i = 0; i < Serial.list().length; i++) {
            String name = Serial.list()[i];
            int dot = name.indexOf('.');
            if (dot >= 0)
                name = name.substring(dot + 1);
            if (!name.contains("luetooth")) {
                comPorts.add(name);
                println(name);
            }
        }
    }


public void disconnect() {
        myPort.write('x');
        if (myPort != null)
            myPort.stop();
        myPort = null;
        println("Disconnected");
        println("No init");
        connected_status=false;
        init_state=false;
    }

 public void connect(int port) {
        
        try {
            myPort = new Serial(applet, Serial.list()[port], (int) baudRate);
            myPort.buffer(1024);
            
            
            connected_status=true;    
            println("Port open.");
            init_state=false;
            connected_status=false;         
        } catch (Exception exp) {
            exp.printStackTrace();
            println(exp);
        }
    }

 public void connect(String name) {
        for (int i = 0; i < Serial.list().length; i++) {
            if (Serial.list()[i].contains(name)) {
                connect(i);
                connected_status=true;    
                return;
            }}
        disconnect();
        
        init_state=false;
        }

   
public void init()
{
  
  delay(100);
  val="ni"; 
  myPort.write('i');

  print("Init:");
  delay(1000);
  while (val.equals("ni")) {
  byte_count++;
  if (byte_count>100) {val="nope";init_state=false; println("Programmer not found.");connected_status=false;}
  myPort.write('i');
  delay(10);
  print("."); while (myPort.available() > 0)   val = myPort.readStringUntil('\n');
  if (val.contains("EEPROM")) {init_state=true; println("Programmer found.");connected_status=true;
   } 
   delay(100);
 
  }
  byte_count=0;
  }
                
 
String myString=""; 
 Textarea myTextarea;
 Textarea myTextarea2;
 Slider slider1;
 Button readbutton;
 Button writebutton;
 Button clearbutton;
 
 DropdownList connectDropList;
 DropdownList select;
 
 public void createcp5GUI()
    {

  cp5 = new ControlP5(this);
  
  myTextarea = cp5.addTextarea("txt")
                .setPosition(80,150)
                .setFont(createFont("Courier New", 13))
                .setLineHeight(18)
                .setColor(0xff000000)
                .setText("")
                .setSize(400,400)
                .enableColorBackground()
                .setColorBackground(color(0xffffffff));           
  myTextarea2 = cp5.addTextarea("txt2")
                .setPosition(20,150)
                .setFont(createFont("Courier New", 13))
                .setLineHeight(18)
                .setColor(0xff000000)
                .hideScrollbar()
                .setText("")
                .setSize(59,400)
                .enableColorBackground()
                .setColorBackground(color(0xfff0fef0));           
              
                
 select= cp5.addDropdownList("selectlist")
                .setPosition(140, 20)
                .setCaptionLabel("Select EEPROM")
                .setItemHeight(20)
                .setBarHeight(20)
                .setSize(100,((eeproms.length+1)*20))
                .setOpen(false)
                .addItems(eeproms);
  
 connectDropList = cp5.addDropdownList("dropListConnect")
                .setPosition(20, 20)
                .setCaptionLabel("Select port")
                .setItemHeight(20)
                .setBarHeight(20)
                .setSize(100,(comPorts.size()+1)*20)
                .setOpen(false)
                .addItems(comPorts);
  
 slider1 = cp5.addSlider("sliderTicks1")
     .setPosition(10,560)
     .setSize(480,20)
     .setRange(0,epromsize)
     .setValue(0)
     .setLabelVisible(false)
     .setVisible(false)
     ;
  
  // and add another 2 buttons
  cp5.addButton("Load_file")
     .setBroadcast(false)
     .setValue(100)
     .setPosition(260,20) 
     .setSize(100,19)
     .setCaptionLabel("Open")
     .setBroadcast(true);
     
     
     cp5.addButton("Save_file")
     .setBroadcast(false)
     .setPosition(380,20)
     .setSize(100,19)
     .setValue(0)
     .setCaptionLabel("Save file")
     .setBroadcast(true);
     
 writebutton = cp5.addButton("Write_EEPROM")
     .setBroadcast(false)
     .setPosition(380,50)
     .setSize(100,19)
     .setValue(0)
     .setCaptionLabel("Write")
     .setBroadcast(true)
     ;
 
 readbutton = cp5.addButton("Read_EEPROM")
     .setBroadcast(false)
     .setPosition(260,50)
     .setSize(100,19)
     .setValue(0)
     .setCaptionLabel("Read EEPROM")
     .setBroadcast(true)
     ;

clearbutton = cp5.addButton("Clear_EEPROM")
     .setBroadcast(false)
     .setPosition(380,80)
     .setSize(100,19)
     .setValue(0)
     .setCaptionLabel("Erase")
     .setBroadcast(true)
     ;

 
     
     



    }
    



public void  Clear_EEPROM()
{
  
  
  
  if (connected_status){
 epromadress=0;step=0;
 byte_count=0;
 status_msg="Erasing...";
 delay(400);
 slider1.setVisible(true);
 eraseeeprom=!eraseeeprom;
 if (eraseeeprom==true) clearbutton.setCaptionLabel("Cancel");
 if (eraseeeprom==false) {clearbutton.setCaptionLabel("Erase");epromadress=0;slider1.setVisible(false);}
 
 
  }
 }
    
public void  Write_EEPROM()
{
  
  data1=myTextarea.getText();
  if (data1.length()<2) {writeeprom=false;println("nothing to write");}  
  else {
  
  if (connected_status){
 epromadress=0;step=0;byte_count=0;
 status_msg="Writing...";
 delay(400);
 slider1.setVisible(true);
 writeeprom=!writeeprom;
 if (writeeprom==true) writebutton.setCaptionLabel("Stop");
 if (writeeprom==false) {writebutton.setCaptionLabel("Write");epromadress=0;slider1.setVisible(false);}
 
 
  }
 }}
    
    
    
    
public void  Read_EEPROM()
{
  if (connected_status){
 epromadress=0;
 status_msg="Reading...";
 delay(400);
 slider1.setVisible(true);
 readeprom=!readeprom;
 String str2="";
 if (readeprom==true) readbutton.setCaptionLabel("Stop");
 if (readeprom==false) {readbutton.setCaptionLabel("Read EEPROM");epromadress=0;slider1.setVisible(false);}
 data1="";
 byte_count=0;}
 }

    
public void Load_file()
{
 selectInput("Select a file to process:", "fileSelected");
 openfile=true;
}

 
public void Save_file()
{
 selectOutput("Select a file to write to:", "fileSelected");
 savefile=true;
 

}




public void controlEvent(ControlEvent theEvent) {
 println(theEvent.getController().getName());
  
  
  
  
  
    if (theEvent.isController()) {
           

            if (("" + theEvent.getController()).contains("dropListConnect"))
            {
                Map m = connectDropList.getItem((int)theEvent.getController().getValue());
                        connect((String) m.get("name"));
            if (init_state==false & connected_status==true ) init();
                
            }
            
               if (("" + theEvent.getController()).contains("selectlist"))
            {
                Map m =select.getItem((int)theEvent.getController().getValue());
                       eeprom((String) m.get("name"));
            
                
            }
            
            
            
            
              }
            }

    
String[] eeproms={"AT28C64B", "CAT28LV65P" ,"AT27C256R"};

public void fileSelected(File selection) {
  if (selection == null) {
    println("Window was closed or the user hit cancel.");file_event=false;
  } else {
    println("User selected " + selection.getAbsolutePath());
    sfilename=selection.getAbsolutePath();
    file_event=true;
  }
}

public void eeprom(String etype)
{
  if (etype.equals("AT28C64B")) epromsize=0x1F40;
  if (etype.equals("CAT28LV65P")) epromsize=0x1F40;
  if (etype.equals("AT27C256R")) epromsize=0xFFFF;
  slider1.setRange(0,epromsize);
  
}
  public void settings() {  size(500,620); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "EEPROM_programer" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
